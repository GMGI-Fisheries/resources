We had a nice chat about how to reboot a couple of proteomic projects.

<video width="100%" controls>
  <source src="http://owl.fish.washington.edu/halfshell/zoom/Proteomics-021018_1920x1004.mp4" type="video/mp4">
  Your browser does not support HTML5 video.
</video>

<p>
Video with audio transcript temporarily available 
<a href="https://washington.zoom.us/recording/play/dBcpvx0miRbpUNpxU64IhT1lQmeMS5W1b4MheZYH6AS9kdLXEeR-emRpbZgX3cyA?autoplay=true" target="_blank">here</a>.
</p>
