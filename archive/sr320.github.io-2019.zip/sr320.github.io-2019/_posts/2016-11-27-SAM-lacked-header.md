---
layout: post
title: SAM lacked header
date: '2016-11-27'
categories: snippet
---


<img src="http://eagle.fish.washington.edu/cnidarian/skitch/More_Bismark_output_tests_1DEB4908.png" alt="More_Bismark_output_tests_1DEB4908.png"/>


