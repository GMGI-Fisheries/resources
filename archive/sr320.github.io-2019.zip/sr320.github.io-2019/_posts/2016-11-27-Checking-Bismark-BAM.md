---
layout: post
title: Checking Bismark BAM
date: '2016-11-27'
categories: snippet
---


<img src="http://eagle.fish.washington.edu/cnidarian/skitch/genefish_1DEB3745.png" alt="genefish_1DEB3745.png"/>

