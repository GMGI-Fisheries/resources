#Atlantic Salmon Tophat

<img src="http://eagle.fish.washington.edu/cnidarian/skitch/_86__Discovery_Environment_1DBFA6D9.png" alt="_86__Discovery_Environment_1DBFA6D9.png"/>

---
<img src="http://eagle.fish.washington.edu/cnidarian/skitch/_86__Discovery_Environment_1DBFA700.png" alt="_86__Discovery_Environment_1DBFA700.png"/>

--