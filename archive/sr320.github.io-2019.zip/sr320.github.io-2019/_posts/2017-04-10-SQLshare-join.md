Here is a set of videos where I      
1) download annotations from UniProt     
2) upload said file to the _new_ SQLShare     
3) upload Blastx output to SQLShare and...     
4) do a `left join`.     

<iframe src="https://uw.hosted.panopto.com/Panopto/Pages/Embed.aspx?id=3ce2442d-fe29-43c2-a91e-163a714e1ec7&v=1" width="720" height="405" style="padding: 0px; border: 1px solid #464646;" frameborder="0" allowfullscreen></iframe>

<iframe src="https://uw.hosted.panopto.com/Panopto/Pages/Embed.aspx?id=05532614-7957-42c9-988d-88235d1663f4&v=1" width="720" height="405" style="padding: 0px; border: 1px solid #464646;" frameborder="0" allowfullscreen></iframe>

<iframe src="https://uw.hosted.panopto.com/Panopto/Pages/Embed.aspx?id=b69c04f4-7498-473f-a520-9315724b77b2&v=1" width="720" height="405" style="padding: 0px; border: 1px solid #464646;" frameborder="0" allowfullscreen></iframe>

<iframe src="https://uw.hosted.panopto.com/Panopto/Pages/Embed.aspx?id=fc9ac6ed-8161-4086-8540-b3f505667575&v=1" width="720" height="405" style="padding: 0px; border: 1px solid #464646;" frameborder="0" allowfullscreen></iframe>

