---
layout: post
title: CoGe on Fidalgo Sibs
date: '2016-05-05'
categories: Sample-Processing
tags: test
tags: shellfish

---



As per [this pipeline](https://genomevolution.org/wiki/index.php/Methylation_Analysis_Pipeline) I will run the 8 individuals in the environmental epigenetics mini-experiment.

<img src="http://eagle.fish.washington.edu/cnidarian/skitch/_94__Discovery_Environment_1CB98355.png" alt="_94__Discovery_Environment_1CB98355.png"/>

---

<img src="http://eagle.fish.washington.edu/cnidarian/skitch/CoGe__My_Data_1CB982D9.png" alt="CoGe__My_Data_1CB982D9.png"/>

---

<img src="http://eagle.fish.washington.edu/cnidarian/skitch/CoGe__My_Data_1CB983D1.png" alt="CoGe__My_Data_1CB983D1.png"/>

---

<img src="http://eagle.fish.washington.edu/cnidarian/skitch/CoGe__My_Data_1CB983F4.png" alt="CoGe__My_Data_1CB983F4.png"/>
---

<img src="http://eagle.fish.washington.edu/cnidarian/skitch/CoGe__My_Data_1CB98449.png" alt="CoGe__My_Data_1CB98449.png"/>

--

Once complete this is all available in the [genome browser](https://genomevolution.org/coge/GenomeView.pl?gid=28863&loc=scaffold77:20000)

<img src="http://eagle.fish.washington.edu/cnidarian/skitch/JBrowse_scaffold3680_9487__72804_1CBB0254.png" alt="JBrowse_scaffold3680_9487__72804_1CBB0254.png"/>
