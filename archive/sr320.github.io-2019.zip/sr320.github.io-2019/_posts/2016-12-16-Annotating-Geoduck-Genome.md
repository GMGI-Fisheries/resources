---
layout: post
title: Annotating Geoduck Genome
date: '2016-12-16'
categories: snippet
---

<img src="http://eagle.fish.washington.edu/cnidarian/skitch/panopea_1E04B901.png" alt="panopea_1E04B901.png"/>

