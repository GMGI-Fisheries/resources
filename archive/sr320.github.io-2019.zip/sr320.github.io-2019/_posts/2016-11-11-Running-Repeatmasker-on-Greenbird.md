---
layout: post
title: Running Repeatmasker on Greenbird
date: '2016-11-11'
categories: snippet
---


![repeat](../images/repeat.gif)


<http://owl.fish.washington.edu/halfshell/2016-11-oly-annotation/RM-Ostrea_lurida-Scaff-10k.fa.out.gff>
