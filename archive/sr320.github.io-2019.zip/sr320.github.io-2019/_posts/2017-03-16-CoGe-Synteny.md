
Exploring various options for comparative genomic in CoGe

<img src="http://eagle.fish.washington.edu/cnidarian/skitch/CoGe__SynMap_1E7B255A.png" alt="CoGe__SynMap_1E7B255A.png"/>

<img src="http://eagle.fish.washington.edu/cnidarian/skitch/CoGe__SynMap_1E7B259C.png" alt="CoGe__SynMap_1E7B259C.png"/>

https://genomevolution.org/r/ntsy

---

