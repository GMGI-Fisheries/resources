Measuring up

Yesterday we did some measuring of the seed and consolidated them into single water source. 

Here is what it looked like when we started.
<img src="http://eagle.fish.washington.edu/cnidarian/skitch/IMG_4947_JPG__33_documents__33_total_pages__and_Ocean_Acidification_–_Research_Notes_from_the_School_of_Aquatic_and_Fishery_Sciences_1CB95D8F.png" alt="IMG_4947_JPG__33_documents__33_total_pages__and_Ocean_Acidification_–_Research_Notes_from_the_School_of_Aquatic_and_Fishery_Sciences_1CB95D8F.png"/>

And at the individual tank view. 
<img src="http://eagle.fish.washington.edu/cnidarian/skitch/IMG_4948_JPG__33_documents__33_total_pages__1CB95E0C.png" alt="IMG_4948_JPG__33_documents__33_total_pages__1CB95E0C.png"/>

<img src="http://eagle.fish.washington.edu/cnidarian/skitch/IMG_4949_JPG__33_documents__33_total_pages__1CB95E2B.png" alt="IMG_4949_JPG__33_documents__33_total_pages__1CB95E2B.png"/>

<img src="http://eagle.fish.washington.edu/cnidarian/skitch/IMG_4950_JPG__33_documents__33_total_pages__1CB95E48.png" alt="IMG_4950_JPG__33_documents__33_total_pages__1CB95E48.png"/>

<img src="http://eagle.fish.washington.edu/cnidarian/skitch/IMG_4951_JPG__33_documents__33_total_pages__1CB95E5F.png" alt="IMG_4951_JPG__33_documents__33_total_pages__1CB95E5F.png"/>

<img src="http://eagle.fish.washington.edu/cnidarian/skitch/IMG_4952_JPG__33_documents__33_total_pages__1CB95E75.png" alt="IMG_4952_JPG__33_documents__33_total_pages__1CB95E75.png"/>

<img src="http://eagle.fish.washington.edu/cnidarian/skitch/IMG_4953_JPG__33_documents__33_total_pages__1CB95E93.png" alt="IMG_4953_JPG__33_documents__33_total_pages__1CB95E93.png"/>

From here ducks were transfered to Taylor pails. Below are photos from each cohort.
<img src="http://eagle.fish.washington.edu/cnidarian/skitch/IMG_4961_JPG__33_documents__33_total_pages__1CB95F55.png" alt="IMG_4961_JPG__33_documents__33_total_pages__1CB95F55.png"/>

<img src="http://eagle.fish.washington.edu/cnidarian/skitch/IMG_4967_JPG__33_documents__33_total_pages__1CB95F8D.png" alt="IMG_4967_JPG__33_documents__33_total_pages__1CB95F8D.png"/>

<img src="http://eagle.fish.washington.edu/cnidarian/skitch/IMG_4965_JPG__33_documents__33_total_pages__1CB95FD4.png" alt="IMG_4965_JPG__33_documents__33_total_pages__1CB95FD4.png"/>

<img src="http://eagle.fish.washington.edu/cnidarian/skitch/IMG_4971_JPG__33_documents__33_total_pages__1CB95FF9.png" alt="IMG_4971_JPG__33_documents__33_total_pages__1CB95FF9.png"/>

<img src="http://eagle.fish.washington.edu/cnidarian/skitch/IMG_4959_JPG__33_documents__33_total_pages__1CB96023.png" alt="IMG_4959_JPG__33_documents__33_total_pages__1CB96023.png"/>

<img src="http://eagle.fish.washington.edu/cnidarian/skitch/IMG_4957_JPG__33_documents__33_total_pages__1CB9604A.png" alt="IMG_4957_JPG__33_documents__33_total_pages__1CB9604A.png"/>

Eight siblings were added to each pail as they were being measured - See Laura's post. They were place nicely in a tank.
<img src="http://eagle.fish.washington.edu/cnidarian/skitch/IMG_4973_JPG__33_documents__33_total_pages__1CB960AD.png" alt="IMG_4973_JPG__33_documents__33_total_pages__1CB960AD.png"/>

Water added.

<iframe width="560" height="315" src="https://www.youtube.com/embed/Fo2mk_-bCkQ?rel=0" frameborder="0" allowfullscreen></iframe>

And there you have it.

<img src="http://eagle.fish.washington.edu/cnidarian/skitch/IMG_4980_JPG__33_documents__33_total_pages__1CB96140.png" alt="IMG_4980_JPG__33_documents__33_total_pages__1CB96140.png"/>

