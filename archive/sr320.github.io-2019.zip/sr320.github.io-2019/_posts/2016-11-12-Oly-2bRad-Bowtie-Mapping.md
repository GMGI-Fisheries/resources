---
layout: post
title: Oly 2bRad Bowtie Mapping
date: '2016-11-12'
categories: snippet
---


Mapped RNA-seq reads yesterday. Today trying 2bRAD that matches BS data.

![jup](http://eagle.fish.washington.edu/cnidarian/skitch/03-Mapping-2bRAD_and_Google_Hangouts_-_roberts_sbr_gmail_com_1DD7B76E.png)

`very-sensitive-local` increases mapped reads. 

