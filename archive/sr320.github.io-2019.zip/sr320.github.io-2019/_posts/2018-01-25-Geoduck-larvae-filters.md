As part of this [Geoduck Larvae Trial](https://ellior2.github.io/Geoduck-Trials-2017/) we will be running some filters through proteomics and metagenomics. 

![pic](http://eagle.fish.washington.edu/cnidarian/skitch/Screenshot_2_10_18__1_25_PM_202F9AD7.png)

Specifically dates 
```
5/15/17
5/19/17
5/22/17
5/26/17
```
Conical #4 and #8 at pH 8.2       
Conical #6 and #9 at pH 7.1

These 16 filters are in a separate bag inside the -80 freezer box:    

![radck](http://eagle.fish.washington.edu/cnidarian/skitch/-80_Inventory_Map_-_Google_Sheets_202F9CB8.png)
