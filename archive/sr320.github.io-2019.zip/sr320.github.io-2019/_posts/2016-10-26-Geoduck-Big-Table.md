---
layout: post
title: Geoduck Big Table
date: '2016-10-26'
categories: snippet
---

Working on the finalizing the big table for the the transcriptome.

<img src="http://eagle.fish.washington.edu/cnidarian/skitch/11-Exploring-the-Big-Table_and_SQLShare_-_View_Query_1DC0E388.png" alt="11-Exploring-the-Big-Table_and_SQLShare_-_View_Query_1DC0E388.png"/>

