---
layout: post
title: Problem with Ssalar blastp
date: '2016-10-26'
categories: snippet
---


<img src="http://eagle.fish.washington.edu/cnidarian/skitch/hummingbird_1DC11E36.png" alt="hummingbird_1DC11E36.png"/>


Update:
10/27 AM      
Seems to do a bit better with dropping cores

<img src="http://eagle.fish.washington.edu/cnidarian/skitch/hummingbird_1DC2359E.png" alt="hummingbird_1DC2359E.png"/>
