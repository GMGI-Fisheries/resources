---
layout: post
title: Gigaton Protein Annotation Complete
date: '2016-10-29'
categories: snippet
---

Ran Blastp against UniProt. 

<img src="http://eagle.fish.washington.edu/cnidarian/skitch/genefish_1DC56C79.png" alt="genefish_1DC56C79.png"/>

[Blast Table](https://raw.githubusercontent.com/sr320/course-fish546-2016/master/jupyter-nbs/analyses/wd-102716/blastout_gigatonpep-uniprot.tab)

