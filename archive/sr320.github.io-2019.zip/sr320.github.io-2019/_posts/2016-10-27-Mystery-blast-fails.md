---
layout: post
title: Mystery blast fails
date: '2016-10-27'
categories: snippet
---

On genefish. Will try splitting.

<img src="http://eagle.fish.washington.edu/cnidarian/skitch/genefish_1DC25991.png" alt="genefish_1DC25991.png"/>


Update - 10-28-2016    

Parts 9 and 10 likely did not complete.     

<img src="http://eagle.fish.washington.edu/cnidarian/skitch/genefish_1DC39FD3.png" alt="genefish_1DC39FD3.png"/>

