
Replacing toaster drive.


![pic](http://eagle.fish.washington.edu/cnidarian/skitch/Alanine_and_sr320_nb-2018_201698CB.png)

---

![sg](http://eagle.fish.washington.edu/cnidarian/skitch/Space_Gremlin_and_New_File_and_Alanine_2016991D.png)


---

Most of the drive is available on Owl http://owl.fish.washington.edu/halfshell/bu-alanine-wd/
