Per this [issue](https://github.com/RobertsLab/resources/issues/50) I took at look at some of Yaamini's data.

Essentially did a join in bash and used excel to look at data.

[Jupyter Notebook](https://github.com/sr320/nb-2017/blob/master/C_gigas/06-MS-data-check.ipynb)

---

[Screencast](https://d.pr/v/MsCGgT)