Draft Olympia Oyster Genome data

Over the next few weeks we expect a flood of _Ostrea lurida_ DNA sequence data.  
Some of the first to be available is raw data produced in order to generate a draft genome.


library  |  	insert size |  	read length
----------|--------------------|-------------
wHAXPI023905-96 | 	300bp |	PE150
wHAIPI023992-37 |	500bp
wHAMPI023991-66	 | 800bp
WHOSTibkDCAADWAAPEI-74	 | 2k |	PE50
WHOSTibkDCABDLAAPEI-62	| 5k
WHOSTibkDCACDTAAPEI-75	| 10k

----

Files can be downloaded here via links below.

<iframe width="500" height="300" scrolling="yes" frameborder="no" src="https://www.google.com/fusiontables/embedviz?viz=GVIZ&amp;t=TABLE&amp;q=select+col0%2C+col1%2C+col2%2C+col3%2C+col4%2C+col5%2C+col6%2C+col7%2C+col8%2C+col9%2C+col10%2C+col11%2C+col12+from+13IxnqIZ_2Xpz_HE-3YcnU_egASYz9ZlA0PYIDGLN+where+col1+%3D+&#39;2016-01-26+00%3A00%3A00&#39;+and+col2+%3D+&#39;O_lurida&#39;&amp;containerId=googft-gviz-canvas"></iframe>
 