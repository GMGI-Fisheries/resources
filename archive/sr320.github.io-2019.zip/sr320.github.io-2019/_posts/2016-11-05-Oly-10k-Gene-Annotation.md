---
layout: post
title: Oly 10k Gene Annotation
date: '2016-11-05'
categories: snippet
---


<img src="http://eagle.fish.washington.edu/cnidarian/skitch/genefish_1DCECD8D.png" alt="genefish_1DCECD8D.png"/>

student repo:   
https://github.com/sr320/student-fish546-2016/blob/master/jupyter/01.5-Ostrea-blast-10k-gf.ipynb

