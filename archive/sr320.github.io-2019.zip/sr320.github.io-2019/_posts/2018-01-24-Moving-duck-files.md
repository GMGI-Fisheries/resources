Getting back to the command line.    

Some chromium 10x files have been moved to the Mox `scrubbed`.     

Some 10x files are locally on Serine, as is what appears to be two assemblies done with Supernova.    

Novaseq MP reads from 
```
http://owl.fish.washington.edu/halfshell/working-directory/17-09-01/
```
are being moved to Mox. a la    

```
wget --recursive --no-parent \
http://owl.fish.washington.edu/halfshell/working-directory/17-09-01/
```

---
Next steps is trying to get some of the Novaseq data asssembled and look at supernova assemblies (.fastb files?).

