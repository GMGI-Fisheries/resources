---
layout: post
title: Why BSMAP limits scallfolds
date: '2016-11-25'
categories: snippet
---

<img src="http://eagle.fish.washington.edu/cnidarian/skitch/genefish_1DE8C255.png" alt="genefish_1DE8C255.png"/>

