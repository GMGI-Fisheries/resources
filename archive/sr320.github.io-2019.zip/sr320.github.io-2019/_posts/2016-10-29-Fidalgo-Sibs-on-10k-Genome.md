---
layout: post
title: Fidalgo Sibs on 10k Genome
date: '2016-10-29'
categories: snippet
---

Running BSMAP on version of _Ostrea lurida_ genome that is limited by 10k minimum scaffold threshold.

<img src="http://eagle.fish.washington.edu/cnidarian/skitch/genefish_1DC572E1.png" alt="genefish_1DC572E1.png"/>

---

<img src="http://eagle.fish.washington.edu/cnidarian/skitch/genefish_1DC57645.png" alt="genefish_1DC57645.png"/>
