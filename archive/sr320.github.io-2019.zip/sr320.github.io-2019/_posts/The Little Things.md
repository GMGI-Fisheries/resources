Getting back into gear, I am assisting Andrew ID some targets from a salmonid transcriptome. With said transcriptome I am taking the [blast output](https://github.com/sr320/nb-2016/blob/master/Crazy-blast-Andrew-1--sp.ipynb) and getting some protein names _sans_ SQLshare. 



