#Since you've been gone

Soon after Ensenada I went to Chili, SICB, and PAG (in that order).  The new year is often of time to let go of lingering projects, and likely I will be doing that soon. But to bring a few pending efforts to the forefront, so that I can analyze etc here is a bit of data that is (or soon will) be coming in.
Much of this is centered around the _Ostrea lurida_.

---
The first batch was 2bRAD data.
![sheet](http://eagle.fish.washington.edu/cnidarian/skitch/Next_Gen_Seq_Library_Database_-_Google_Sheets_1C4FE9FC.png)

The full list of samples are [here](https://docs.google.com/spreadsheets/d/1DJP4zpF3OcISOAQ-MM8bW85WcJqdB5EvcExs2wGvzcg/edit?usp=sharing).

![sc](http://eagle.fish.washington.edu/cnidarian/skitch/White_BS1511196_R2_barcodes_-_Google_Sheets_and_White_BS1511196_R2_barcodes_-_Google_Sheets_1C4FEC36.png)

These raw data are [here](http://owl.fish.washington.edu/nightingales/O_lurida/2bRAD_Dec2015/).

A quick fastqc....


----

**We also now have a fresh set of MBD-BS..**  now out for sequencing. 
[Pregame here](http://onsnetwork.org/kubu4/category/olympia-oyster-reciprocal-transplant/mbd-enrichment-for-sequencing-at-zymoresearch/)

![pic}http://eagle.fish.washington.edu/cnidarian/skitch/MBD_Enrichment_for_Sequencing_at_ZymoResearch___Sam_s_Notebook_1C4FF251.png)

---
**And just some plain old BS** 
![pic](http://eagle.fish.washington.edu/cnidarian/skitch/BS-seq_Libraries_for_Sequencing_at_Genewiz___Sam_s_Notebook_1C4FF20D.png)

[Details](http://onsnetwork.org/kubu4/category/olympia-oyster-reciprocal-transplant/bs-seq-libraries-for-genewiz/)
