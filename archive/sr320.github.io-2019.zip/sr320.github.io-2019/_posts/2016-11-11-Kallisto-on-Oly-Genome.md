---
layout: post
title: Kallisto on Oly Genome
date: '2016-11-11'
categories: snippet
---

![oly](http://eagle.fish.washington.edu/cnidarian/skitch/_Busy__02_5-Mapping-Oly-Reads_1DD62952.png)

