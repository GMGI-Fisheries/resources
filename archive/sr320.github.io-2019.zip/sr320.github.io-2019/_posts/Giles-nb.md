# Giles' Notebook

onofficial notes on relevant work 

### Genome Asssembly

0005 - Sablefish Genome Project - Lab Notebook [link](https://github.com/sr320/nb-2016/blob/master/notes/0005-SablefishGenomeProject.pdf)

<img src="http://eagle.fish.washington.edu/cnidarian/skitch/0005_1D131CE3.png" alt="0005_1D131CE3.png"/>


### RAD
0003 - Steelhead RADseq Project [link](https://github.com/sr320/nb-2016/blob/master/notes/0003-SteelheadRADseqProject.pdf)

<img src="http://eagle.fish.washington.edu/cnidarian/skitch/0003_1D131D93.png" alt="0003_1D131D93.png"/>
