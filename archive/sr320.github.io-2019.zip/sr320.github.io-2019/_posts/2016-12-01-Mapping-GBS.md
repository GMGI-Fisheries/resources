---
layout: post
title: Mapping GBS
date: '2016-12-01'
categories: snippet
---


<img src="http://eagle.fish.washington.edu/cnidarian/skitch/03_5-Mapping-GBS_1DF09297.png" alt="03_5-Mapping-GBS_1DF09297.png"/>

