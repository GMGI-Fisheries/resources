Some summary environmental data for DNR project

<img src="http://eagle.fish.washington.edu/cnidarian/skitch/Screenshot_9_13_17__1_29_PM_1F69CCF2.png" alt="Screenshot_9_13_17__1_29_PM_1F69CCF2.png"/>
