We have a few MiSeq files.

see also [this notebook](https://github.com/sr320/nb-2017/blob/master/P_generosa/29-MiSeq%20Files.ipynb)

Not very clear what they were but here is the SampleSheet

```
[Header],,,,,,,
IEMFileVersion,4,,,,,,
Investigator Name,Jon Hetzel,,,,,,
Experiment Name,GeoDuckRNAMiSeq,,,,,,
Date,3/15/2017,,,,,,
Workflow,GenerateFASTQ,,,,,,
Application,RNA-Seq,,,,,,
Assay,TruSeq LT,,,,,,
Description,,,,,,,
Chemistry,Default,,,,,,
,,,,,,,
[Reads],,,,,,,
76,,,,,,,
76,,,,,,,
,,,,,,,
[Settings],,,,,,,
Adapter,AGATCGGAAGAGCACACGTCTGAACTCCAGTCA,,,,,,
AdapterRead2,AGATCGGAAGAGCGTCGTGTAGGGAAAGAGTGT,,,,,,
,,,,,,,
[Data],,,,,,,
Sample_ID,Sample_Name,Sample_Plate,Sample_Well,I7_Index_ID,index,Sample_Project,Description
1,1,1,A1,A006,GCCAAT,,GeoduckGonadRNA
2,2,1,B1,A013,AGTCAA,,GeoduckHeartRNA
3,3,1,C1,A012,CTTGTA,,GeoduckCtenidiaRNA
4,4,1,D1,A014,AGTTCC,,GeoduckJuvenileOARNAEPI115
5,5,1,E1,A005,ACAGTG,,GeoduckJuvenileOARNAEPI116
6,6,1,F1,A015,ATGTCA,,GeoduckJuvenileAmbientRNAEPI123
7,7,1,G1,A019,GTGAAA,,GeoduckJuvenileAmbientRNAEPI124
8,8,1,H1,A021,GTTTCG,,GeoduckLarvaeDay5RNAEPI99

```
---

```
./4-43871086/4_S4_L001_R1_001.fastq.gz
./4-43871086/4_S4_L001_R2_001.fastq.gz
./1-43865084/1_S1_L001_R1_001.fastq.gz
./1-43865084/1_S1_L001_R2_001.fastq.gz
./3-43862058/3_S3_L001_R1_001.fastq.gz
./3-43862058/3_S3_L001_R2_001.fastq.gz
./5-43878904/5_S5_L001_R1_001.fastq.gz
./5-43878904/5_S5_L001_R2_001.fastq.gz
./7-43866069/7_S7_L001_R1_001.fastq.gz
./7-43866069/7_S7_L001_R2_001.fastq.gz
./2-43876910/2_S2_L001_R1_001.fastq.gz
./2-43876910/2_S2_L001_R2_001.fastq.gz
./6-43868087/6_S6_L001_R1_001.fastq.gz
./6-43868087/6_S6_L001_R2_001.fastq.gz
./8-43874887/8_S8_L001_R1_001.fastq.gz
./8-43874887/8_S8_L001_R2_001.fastq.gz
```

online [here](http://owl.fish.washington.edu/halfshell/working-directory/17-09-06b/)
