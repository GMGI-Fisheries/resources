---
layout: post
title: Big Table Nb
date: '2016-10-26'
categories: snippet
---

Link to notebook exploring the table
<https://github.com/sr320/paper-pano-go/blob/master/jupyter-nbs/11-Exploring-the-Big-Table.ipynb>

