---
layout: post
title: Ssalar Protein Annotation Complete
date: '2016-10-28'
categories: snippet
---

With a third blasting and comparing hits for all 10 parts of the query, I am satisfied with the output.

<https://raw.githubusercontent.com/sr320/sr320.github.io/master/jupyter/Ssalar/data/GCF_000233375.1_ICSASG_v2_protein_blastp_uniprot.tab>

<img src="http://eagle.fish.washington.edu/cnidarian/skitch/hummingbird_1DC39EA7.png" alt="hummingbird_1DC39EA7.png"/>

