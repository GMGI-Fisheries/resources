---
layout: post
title: phone
date: '2016-09-21'
categories: 
tags: 

---

Examples of local image





![test](https://github.com/hputnam/project_juvenile_geoduck_OA/blob/master/Sample_Processing/Gels/20161003_DNA_Gel_2.jpeg?raw=true)









| Week | Description | Reading |  Quiz
| ------ | ----------- | ------ | ----------- |
| [zero](http://sr320.github.io/course-fish546-2016/00-Notes/)   | [Biology](https://github.com/sr320/course-fish546-2016/blob/master/00-Notes/BioInfo_Intro.pdf), Course Framework, Getting set-up   |  Preface xiii-xxv; How to Learn Bioinformatics 1-18 | [Questions](https://github.com/sr320/course-fish546-2016/issues?utf8=%E2%9C%93&q=is%3Aissue%20label%3Aquiz%20milestone%3A%22Week%200%22%20)
| one   | [Bash](https://github.com/sr320/course-fish546-2016/blob/master/01-Notes/Tutorials/Navigating-commandline.md), version control, Project Set-up |  Setting Up and Managing a Bioinformatics Project 21-35; Remedial Unix Shell 37-54 |  [Questions](https://github.com/sr320/course-fish546-2016/issues?utf8=%E2%9C%93&q=is%3Aissue%20label%3Aquiz%20milestone%3A%22Week%201%22%20)
| two | Jupyter, Annotation  | Bioinformatics Data 109-124, Unix Data tools 125-168
| three   | RNA-seq  | Working with Sequence Data 339-354, Git for Scientists 67-83, 
| four  | lncRNA  | 
| five | Proteomics  | 
| six   | DNA methylation  |
| seven   | Genome Browser  |  Working with Alignment Data 355-383, Working with Range Data 263-338
| eight | SNP-GBS/RAD  |
| nine   | Projects  |
| ten  | Projects  |






This is my post from my phone 
Not
*bold*

This is me trying to use voice recognition on my telephone and water to make a post.

Voice

https://drive.google.com/open?id=0BwVK83sm6XQGNFhULTczcFBiMGM

https://www.dropbox.com/s/ynchaxekht5ncg5/New%20Recording%205.m4a?dl=0

[dropbox](https://www.dropbox.com/s/ynchaxekht5ncg5/New%20Recording%205.m4a?dl=0)


