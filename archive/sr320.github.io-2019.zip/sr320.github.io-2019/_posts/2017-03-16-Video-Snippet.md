

<iframe src="https://uw.hosted.panopto.com/Panopto/Pages/Embed.aspx?id=dced3a91-4964-47ff-861d-d27d8d2a5c3c&v=1" width="720" height="405" style="padding: 0px; border: 1px solid #464646;" frameborder="0" allowfullscreen></iframe>
