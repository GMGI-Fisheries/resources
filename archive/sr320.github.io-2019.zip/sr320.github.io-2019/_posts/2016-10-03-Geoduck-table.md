---
layout: post
title: Geoduck data table
date: '2016-10-03'
categories: Panopea
tags: annotation
tags: geoduck

---


Getting closer to a master table for a the gonad transcriptome.

![sc](http://eagle.fish.washington.edu/cnidarian/skitch/Screenshot_10_3_16__7_52_AM_1DA2A912.png)
