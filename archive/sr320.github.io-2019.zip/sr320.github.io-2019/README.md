readme

My lab notebook.

Based on (forked from) https://github.com/barryclark/jekyll-now
